package com.examplebotones.hipotenochapro

import android.app.AlertDialog
import android.content.Context

class DialogoOpciones(private val context: Context, private val callback: DialogoOpcionesCallback) {

    fun mostrarDialogo() {
        val dificultades = arrayOf("Principiante", "Amateur", "Avanzado")

        AlertDialog.Builder(context)
            .setTitle("Selecciona la dificultad")
            .setSingleChoiceItems(dificultades, -1) { dialog, which ->
                val dificultadSeleccionada = dificultades[which]

                callback.onDificultadSeleccionada(dificultadSeleccionada)
                dialog.dismiss()
            }

            .setNegativeButton("Cancelar") { dialog, _ ->
                dialog.dismiss()
            }
            .create()
            .show()
    }
}

interface DialogoOpcionesCallback {
    fun onDificultadSeleccionada(dificultad: String)
}