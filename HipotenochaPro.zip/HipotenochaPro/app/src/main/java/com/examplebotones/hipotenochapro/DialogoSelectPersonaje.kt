package com.examplebotones.hipotenochapro

import android.R
import android.content.Context
import android.view.View
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.LinearLayout
import android.widget.Spinner
import androidx.appcompat.app.AlertDialog

class DialogoSelectPersonaje(
    private val context: Context,
    private var callback: DialogoPersonajesCallback
) {

    fun mostrarPersonajes() {
        val personajes = arrayOf(
            "Abstracta",
            "Afortunada",
            "Camuflada",
            "Che",
            "DeIncognito",
            "Espanola",
            "Geo",
            "Informatica",
            "Nocturna"
        )

        val adapter = ArrayAdapter(context, R.layout.simple_spinner_item, personajes)

        val spinner = Spinner(context).apply {
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply {
                setMargins(0, 20, 0, 20)
            }

            this.adapter = adapter

            onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
                override fun onItemSelected(
                    parent: AdapterView<*>?,
                    view: View?,
                    position: Int,
                    id: Long
                ) {
                    val nombrePersonaje = personajes[position]
                    callback.onPersonajeSeleccionada(
                        obtenerImagenIdPorNombre(nombrePersonaje),
                        nombrePersonaje
                    )
                }

                override fun onNothingSelected(parent: AdapterView<*>?) {
                    // No se hace nada si no se selecciona nada
                }
            }
        }

        AlertDialog.Builder(context)
            .setTitle("Selecciona un personaje")
            .setView(spinner)
            .setNegativeButton("Volver") { dialog, _ -> dialog.dismiss() }
            .create().show()
    }

    private fun obtenerImagenIdPorNombre(nombre: String): Int {
        return context.resources.getIdentifier(
            nombre.toLowerCase(),
            "drawable",
            context.packageName
        )
    }
}

interface DialogoPersonajesCallback {
    fun onPersonajeSeleccionada(idPersonaje: Int, nombre: String)
}
