package com.examplebotones.hipotenochapro

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.view.Menu
import android.view.MenuItem
import android.widget.Toast
import androidx.activity.result.ActivityResult
import androidx.activity.result.ActivityResultLauncher
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.lifecycle.ReportFragment.Companion.reportFragment
import com.examplebotones.hipotenochapro.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity(), DialogoOpcionesCallback, DialogoPersonajesCallback {


    private lateinit var binding: ActivityMainBinding
    private lateinit var launcher: ActivityResultLauncher<Intent>
    private var dificultad: String = "Principiante"
    private var personaje: String = "che"
    var resourceIDImagen: Int = R.drawable.che

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        //DAMOS VALOR AL LAUNCHER
        launcher = registerForActivityResult(
            ActivityResultContracts.StartActivityForResult(),
            ::onActivityResult
        )
        compIntent()
        botonComenzar()
        textoInicio()
    }

    private fun compIntent() {
        val idImagen = intent.getIntExtra("id", -1)

        if (idImagen != -1) {
            // El valor de idImagen no es nulo, puedes realizar la acción aquí
            resourceIDImagen = idImagen
        }

        if (intent.getStringExtra("nombre") != null) {
            personaje = intent.getStringExtra("nombre").toString()
        }
        if (intent.getStringExtra("dificultad") != null) {
            dificultad = intent.getStringExtra("dificultad").toString()
        }

    }

    private fun onActivityResult(result: ActivityResult) {
        //no hacer nada aquí de momento.
    }

    //la funcion del boton principal
    private fun botonComenzar() {
        binding.btnComenzar.setOnClickListener {
            val intent = Intent(this, MainJuego::class.java)
            intent.putExtra("DIFICULTAD_SELECCIONADA", dificultad)
            intent.putExtra("IMAGEN_SELECCIONADA", resourceIDImagen)
            intent.putExtra("NOMBRE", personaje)
            startActivity(intent)
        }
    }

    //ponemos la imagen al principio y la dificultad...
    private fun textoInicio() {
        binding.tvuno.text = "- Dificultad: $dificultad\n- Personaje: $personaje"
        binding.imgPerson.setImageResource(resourceIDImagen)
    }

    //metodos de las clases ----------------------------------------------------------
    override fun onDificultadSeleccionada(dificultades: String) {
        dificultad = dificultades
        textoInicio()
    }

    override fun onPersonajeSeleccionada(idPersonaje: Int, nombre: String) {
        resourceIDImagen = idPersonaje
        personaje = nombre
        textoInicio()
    }

    //Opciones Menu --------------------------------------------------------------------------------
    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        menuInflater.inflate(R.menu.menu_juego, menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        when (item.itemId) {
            R.id.itemUno -> instrucciones()
            R.id.itemDos -> comenzarJuego()
            R.id.itemTres -> configurarJuego()
            R.id.itemCuatro -> seleccionarPersonaje()
        }
        return super.onOptionsItemSelected(item)
    }

    //Texto con las instrucciones
    private fun instrucciones() {
        val builder = AlertDialog.Builder(this)
        builder.setTitle("Instrucciones")
            .setMessage(
                "Tu objetivo es replicar y programar el mismo " +
                        "juego, dotándole si quieres, de tu toque personal.Es " +
                        "decir, en lugar de buscar hipotenochas, puedes" +
                        "buscar algún otro tipo de personaje.\n"
            )
            .setPositiveButton("OK") { dialog, _ -> }
            .create().show()
    }

    //comienza el juego
    private fun comenzarJuego() {
        val intent = Intent(this, MainJuego::class.java)
        intent.putExtra("DIFICULTAD_SELECCIONADA", dificultad)
        intent.putExtra("IMAGEN_SELECCIONADA", resourceIDImagen)
        intent.putExtra("NOMBRE", personaje)
        startActivity(intent)
    }

    //dialogo con la dificultad
    private fun configurarJuego() {
        val dialogoOpciones = DialogoOpciones(this, this)
        dialogoOpciones.mostrarDialogo()
    }

    //Seleccionamos un personaje
    private fun seleccionarPersonaje() {
        val dialogoPersonaje = DialogoSelectPersonaje(this, this)
        dialogoPersonaje.mostrarPersonajes()
    }
}

