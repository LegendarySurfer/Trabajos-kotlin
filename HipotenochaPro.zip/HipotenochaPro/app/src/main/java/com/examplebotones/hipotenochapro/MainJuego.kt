package com.examplebotones.hipotenochapro

import android.content.Intent
import android.graphics.Point
import android.os.Bundle
import android.util.Log
import android.view.Display
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.examplebotones.hipotenochapro.databinding.ActivityMainJuegoBinding
import java.util.Random

class MainJuego : AppCompatActivity(), View.OnClickListener, View.OnLongClickListener {

    private lateinit var binding: ActivityMainJuegoBinding
    private var anchoPantalla: Int = 0
    private var altoPantalla: Int = 0
    private lateinit var b: Button
    private var nombre: String = ""
    private var resourceIDImagen: Int = 0 // Puedes definir una imagen predeterminada
    private lateinit var esImagen: Array<Array<Boolean>>
    private var contadorHipotenochas: Int = 0
    private var dificultadGrande: String = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainJuegoBinding.inflate(layoutInflater)
        setContentView(binding.root)
        supportActionBar?.hide() //ocultamos la pantalla
        obtenerTamanoPantalla()

        val dificultad = intent.getStringExtra("DIFICULTAD_SELECCIONADA") ?: "Principiante"
        nombre = intent.getStringExtra("NOMBRE").toString()

        dificultadGrande = dificultad
        val imagenId = intent.getIntExtra("IMAGEN_SELECCIONADA", R.drawable.che)
        resourceIDImagen = imagenId
        anadirBotones(dificultad)
    }

    override fun onLongClick(v: View?): Boolean {
        if (v is Button) {
            val fila = obtenerFilaDelBoton(v)
            val columna = obtenerColumnaDelBoton(v)
            if (fila != -1 && columna != -1) {
                if (esImagen[fila][columna]) {
                    mostrarImagen(v)
                    contadorHipotenochas++
                    compruebaSiHasGanado()
                    return true // Devuelve true para indicar que el evento ha sido manejado
                } else {
                    finJuego(v)
                }
            }
        }
        return false // Devuelve false si no se maneja el evento de clic largo
    }

    private fun compruebaSiHasGanado() {
        when (dificultadGrande) {
            "Principiante" -> {
                if (contadorHipotenochas == 10) {
                    hasGanado()
                }
            }

            "Amateur" -> {
                if (contadorHipotenochas == 30) {
                    hasGanado()
                }
            }

            "Avanzado" -> {
                if (contadorHipotenochas == 30) {
                    hasGanado()
                }
            }
        }
    }

    private fun obtenerTamanoPantalla() {
        val display: Display = (getSystemService(WINDOW_SERVICE) as WindowManager).defaultDisplay
        val size = Point()
        display.getSize(size)

        anchoPantalla = size.x
        altoPantalla = size.y

    }

    private fun anadirBotones(dificultad: String) {
        when (dificultad) {
            "Principiante" -> anadirBotones(8, 64, 10)
            "Amateur" -> anadirBotones(12, 144, 30)
            "Avanzado" -> anadirBotones(16, 256, 60)
        }
    }

    private fun anadirBotones(columnas: Int, numBotones: Int, numHipotenochas: Int) {
        binding.glBotones.columnCount = columnas
        val random = Random()
        esImagen = Array(columnas) { Array(columnas) { false } }

        var contadorHipotenochas = numHipotenochas
        b = Button(this)
        for (i in 0 until columnas) {
            for (j in 0 until columnas) {
                val b = Button(this)
                b.layoutParams =
                    ViewGroup.LayoutParams(anchoPantalla / columnas, altoPantalla / columnas)

                b.setOnLongClickListener(this)
                b.setOnClickListener(this)

                if (random.nextInt(11) < 9) {
                    esImagen[i][j] = false // Asigna false cuando no hay imagen
                } else {
                    if (contadorHipotenochas > 0) {
                        esImagen[i][j] = true// Asigna true cuando hay imagen
                        contadorHipotenochas--
                    } else {
                        esImagen[i][j] = false // Asigna false cuando no hay imagen
                    }
                }

                binding.glBotones.addView(b)
            }
            Log.i("TAG", numHipotenochas.toString())
        }

    }

    override fun onClick(v: View?) {
        if (v is Button) {
            val fila = obtenerFilaDelBoton(v)
            val columna = obtenerColumnaDelBoton(v)

            if (fila != -1 && columna != -1) {
                if (esImagen[fila][columna]) {
                    mostrarImagen(v)
                    finJuego(v)
                } else {
                    // Si la casilla está vacía, oculta la casilla y sus casillas cercanas
                    if (v.visibility != View.INVISIBLE) {
                        ocultarCasillasCercanas(fila, columna)
                    }

                    // También puedes agregar lógica adicional aquí, por ejemplo, verificar si el jugador ha ganado.
                }
            }
        }
    }

    private fun ocultarCasillasCircundantes(fila: Int, columna: Int) {
        // Define las posiciones circundantes
        val posicionesCircundantes = arrayOf(
            Pair(fila - 1, columna - 1), Pair(fila - 1, columna), Pair(fila - 1, columna + 1),
            Pair(fila, columna - 1), Pair(fila, columna + 1),
            Pair(fila + 1, columna - 1), Pair(fila + 1, columna), Pair(fila + 1, columna + 1)
        )

        // Oculta las casillas circundantes si no contienen hipotenochas ni números
        for ((filaCercana, columnaCercana) in posicionesCircundantes) {
            if (esPosicionValida(filaCercana, columnaCercana)) {
                val boton = obtenerBotonEnPosicion(filaCercana, columnaCercana)
                if (boton != null && !esImagen[filaCercana][columnaCercana] && boton.text.toString()
                        .isEmpty()
                ) {
                    boton.visibility = View.INVISIBLE
                }
            }
        }
    }

    private fun ocultarCasillasCercanas(fila: Int, columna: Int) {
        // Verifica si las coordenadas están dentro de los límites del GridLayout
        if (fila >= 0 && fila < binding.glBotones.rowCount && columna >= 0 && columna < binding.glBotones.columnCount) {
            // Calcula la posición en el array
            val posicion = fila * binding.glBotones.columnCount + columna

            // Obtiene el botón correspondiente
            val boton = binding.glBotones.getChildAt(posicion) as? Button

            // Verifica si la casilla no ha sido revelada
            if (boton?.visibility != View.INVISIBLE) {
                val hipotenochasCercanas = comprobarArea(fila, columna)

                // Si hay hipotenochas cercanas, muestra el número
                if (hipotenochasCercanas > 0) {
                    boton?.text = hipotenochasCercanas.toString()
                } else {
                    // Si la casilla está vacía, oculta la casilla y continúa la búsqueda en profundidad
                    boton?.visibility = View.INVISIBLE

                    // Busca en profundidad en las casillas adyacentes
                    ocultarCasillasCercanas(fila - 1, columna)
                    ocultarCasillasCercanas(fila + 1, columna)
                    ocultarCasillasCercanas(fila, columna - 1)
                    ocultarCasillasCercanas(fila, columna + 1)
                }
            }
        }
    }

    private fun comprobarArea(fila: Int, columna: Int): Int {
        var contador = 0

        // Verifica el cuadrado de alrededor (3x3)
        for (i in fila - 1..fila + 1) {
            for (j in columna - 1..columna + 1) {
                // Verifica si las coordenadas están dentro de los límites del GridLayout
                if (i >= 0 && i < binding.glBotones.rowCount && j >= 0 && j < binding.glBotones.columnCount) {
                    // Calcula la nueva posición en el array
                    val nuevaPosicion = i * binding.glBotones.columnCount + j

                    // Verifica si hay una hipotenusa en esa posición
                    if (esImagen[i][j]) {
                        contador++
                    }
                }
            }
        }

        return contador
    }

    private fun explorarAlrededor(fila: Int, columna: Int) {
        // Define las posiciones circundantes
        val posicionesCircundantes = arrayOf(
            Pair(fila - 1, columna - 1), Pair(fila - 1, columna), Pair(fila - 1, columna + 1),
            Pair(fila, columna - 1), Pair(fila, columna + 1),
            Pair(fila + 1, columna - 1), Pair(fila + 1, columna), Pair(fila + 1, columna + 1)
        )

        // Contador para contar las hipotenochas cercanas
        var hipotenochasCercanas = 0

        // Verifica las posiciones circundantes
        for ((filaCercana, columnaCercana) in posicionesCircundantes) {
            if (esPosicionValida(
                    filaCercana,
                    columnaCercana
                ) && esImagen[filaCercana][columnaCercana]
            ) {
                // Hay una "hipotenocha" en la posición cercana
                hipotenochasCercanas++
                Log.d(
                    "HipotenochasCercanas",
                    "Número de hipotenochas cercanas: $hipotenochasCercanas"
                )
            }
        }

        // Muestra el número de hipotenochas cercanas en el botón correcto
        val boton = obtenerBotonEnPosicion(fila, columna)
        if (hipotenochasCercanas > 0 && boton != null) {
            boton.visibility = View.VISIBLE
            boton.text = hipotenochasCercanas.toString()
        } else {
            // No hay hipotenochas cercanas, oculta las casillas circundantes
            ocultarCasillasCircundantes(fila, columna)
        }
    }

    private fun esPosicionValida(fila: Int, columna: Int): Boolean =
        fila in 0 until esImagen.size && columna in 0 until esImagen[0].size

    private fun obtenerBotonEnPosicion(fila: Int, columna: Int): Button? {
        val indice = fila * binding.glBotones.columnCount + columna
        return if (indice >= 0 && indice < binding.glBotones.childCount) {
            binding.glBotones.getChildAt(indice) as? Button
        } else {
            null
        }
    }

    private fun finJuego(v: View) {
        v.rotation = 180f
        val builder = AlertDialog.Builder(this)
        builder.setTitle("Juego Terminado")
            .setMessage(
                "Te has topado con una hipotenocha o has marcado una casilla que no tenia hipotenocha" +
                        " y has perdido, volviendo al menu."
            )
            .setPositiveButton("Menu") { dialog, _ ->
                val intent = Intent(this, MainActivity::class.java)
                // Iniciar la nueva actividad

                intent.putExtra("id", resourceIDImagen)
                intent.putExtra("dificultad", dificultadGrande)
                intent.putExtra("nombre", nombre)
                startActivity(intent)
                // Cierra la actividad actual
                finish()
            }
            .create().show()
    }

    private fun hasGanado() {
        val builder = AlertDialog.Builder(this)
        builder.setTitle("Juego Terminado")
            .setMessage(
                "¡¡¡HAS GANADO!!!"
            )
            .setPositiveButton("Menu") { dialog, _ ->
                val intent = Intent(this, MainActivity::class.java)
                // Iniciar la nueva actividad

                intent.putExtra("id", resourceIDImagen)
                intent.putExtra("dificultad", dificultadGrande)
                intent.putExtra("nombre", nombre)
                startActivity(intent)
                // Cierra la actividad actual
                finish()
            }
            .create().show()
    }

    private fun hipotenochasCerca(v: Button) {
        val fila = obtenerFilaDelBoton(v)
        val columna = obtenerColumnaDelBoton(v)

        // Define las posiciones circundantes
        val posicionesCircundantes = arrayOf(
            Pair(fila - 1, columna - 1), Pair(fila - 1, columna), Pair(fila - 1, columna + 1),
            Pair(fila, columna - 1), Pair(fila, columna + 1),
            Pair(fila + 1, columna - 1), Pair(fila + 1, columna), Pair(fila + 1, columna + 1)
        )

        // Contador para contar las hipotenochas cercanas
        var hipotenochasCercanas = 0

        // Verifica las posiciones circundantes
        for ((filaCercana, columnaCercana) in posicionesCircundantes) {
            if (esPosicionValida(
                    filaCercana,
                    columnaCercana
                ) && esImagen[filaCercana][columnaCercana]
            ) {
                // Hay una "hipotenocha" en la posición cercana
                hipotenochasCercanas++
                Log.d(
                    "HipotenochasCercanas",
                    "Número de hipotenochas cercanas: $hipotenochasCercanas"
                )
            }
        }

        // Muestra el número de hipotenochas cercanas en el botón
        if (hipotenochasCercanas > 0) {
            v.visibility = View.VISIBLE
            v.text = hipotenochasCercanas.toString()
        } else {
            // No hay hipotenochas cercanas, puedes realizar alguna acción alternativa si lo deseas
            v.visibility = View.INVISIBLE
        }
    }

    private fun obtenerFilaDelBoton(boton: Button): Int =
        binding.glBotones.indexOfChild(boton) / binding.glBotones.columnCount

    private fun obtenerColumnaDelBoton(boton: Button): Int =
        binding.glBotones.indexOfChild(boton) % binding.glBotones.columnCount

    private fun mostrarImagen(v: Button) {
        val drawable = ContextCompat.getDrawable(this, resourceIDImagen)
        v.background = drawable
    }
}