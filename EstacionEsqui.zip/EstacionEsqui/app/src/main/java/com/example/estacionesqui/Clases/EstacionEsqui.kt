package com.example.estacionesqui.Clases

data class EstacionEsqui(
    val id: Int,
    val nombre: String,
    val cordillera: String,
    val nRemontes: Int,
    val kmPistas: Float,
    val fechaUltVisita: Long,
    val valoracion: Float,
    val notas: String
)
