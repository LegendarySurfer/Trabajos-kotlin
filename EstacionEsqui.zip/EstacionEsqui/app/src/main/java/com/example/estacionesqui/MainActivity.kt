package com.example.estacionesqui

import BDManager
import com.example.estacionesqui.Clases.EstacionEsqui
import com.example.estacionesqui.Adapter.Adapter
import android.annotation.SuppressLint
import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.estacionesqui.BBDD.BDContract
import com.example.estacionesqui.BBDD.BDHelper
import com.example.estacionesqui.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private lateinit var recyclerView: RecyclerView
    private lateinit var adapter: Adapter
    private lateinit var helper: BDHelper
    private lateinit var manager: BDManager

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        helper = BDHelper(this)
        manager = BDManager(helper.writableDatabase)

        actualizarLabel()

        initRecyclerView()

        initUI()

        recyclerView.adapter = adapter
    }

    //----------------------------------------------------------------------------------------------
    private fun actualizarLabel() {
        binding.tvRegistros.text = "Numero de registros: " + manager.obtenerNumeroRegistros()
    }

    private fun initUI() {
        binding.btnAgregar.setOnClickListener { btnAgregar() }
    }

    private fun btnAgregar() {
        val intent = Intent(this, EditEsqui::class.java)
        startActivity(intent)
    }

    //initReciclerView------------------------------------------------------------------------------
    private fun initRecyclerView() {
        recyclerView = binding.rvEsqui
        recyclerView.layoutManager = LinearLayoutManager(this)
        adapter = Adapter(this, obtenerEstacionesDesdeBD())

        // Registrar el RecyclerView para el menú contextual
        registerForContextMenu(recyclerView)

        adapter.setOnItemLongClickListener(object : Adapter.OnItemLongClickListener {
            override fun onItemLongClick(view: View?, position: Int) {
                //mostrar mensaje de si quiere borrar
                mostrarDialogoBorrar(position)
            }
        })

        recyclerView.adapter = adapter
    }

    private fun mostrarDialogoBorrar(position: Int) {
        val dialog = AlertDialog.Builder(this)
            .setTitle("Borrar")
            .setPositiveButton("Borrar") { dialog, _ ->
                val idd = manager.obtenerIdEstacion(position)
                Log.d("ESTACION_1234", "Posicion: $position - EstacionID:$idd")
                manager.borrarEstacion(idd + 1)
                actualizarLabel()
                mostrarMensajeBorrado()
                initRecyclerView()
                dialog.dismiss()
            }
            .create()

        dialog.show()
    }

    private fun mostrarMensajeBorrado() {
        Toast.makeText(this, "Estación de esquí borrada", Toast.LENGTH_SHORT).show()
    }

    @SuppressLint("Range")
    private fun obtenerEstacionesDesdeBD(): ArrayList<EstacionEsqui> {
        val cursor =
            helper.readableDatabase.rawQuery("SELECT * FROM ${BDContract.Esqui.tableName}", null)
        val estacionEsqui = arrayListOf<EstacionEsqui>()

        // Verificar si hay datos en el cursor
        if (cursor.moveToFirst()) {
            do {
                // Obtener los datos de cada columna del cursor
                val id = cursor.getInt(cursor.getColumnIndex(BDContract.Esqui.COLUMN_ID))
                val nombre = cursor.getString(cursor.getColumnIndex(BDContract.Esqui.COLUMN_NOMBRE))
                val cordillera =
                    cursor.getString(cursor.getColumnIndex(BDContract.Esqui.COLUMN_CORDILLERA))
                val nRemontes =
                    cursor.getInt(cursor.getColumnIndex(BDContract.Esqui.COLUMN_N_REMONTES))
                val kmPistas =
                    cursor.getFloat(cursor.getColumnIndex(BDContract.Esqui.COLUMN_KM_PISTAS))
                val fechaUltVisita =
                    cursor.getLong(cursor.getColumnIndex(BDContract.Esqui.COLUMN_FECHA_ULT_VISITA))
                val valoracion =
                    cursor.getFloat(cursor.getColumnIndex(BDContract.Esqui.COLUMN_VALORACION))
                val notas = cursor.getString(cursor.getColumnIndex(BDContract.Esqui.COLUMN_NOTAS))

                // Crear un objeto EstacionEsqui y agregarlo a la lista
                val estacion = EstacionEsqui(
                    id,
                    nombre,
                    cordillera,
                    nRemontes,
                    kmPistas,
                    fechaUltVisita,
                    valoracion,
                    notas
                )
                estacionEsqui.add(estacion)
            } while (cursor.moveToNext())
        }
        cursor.close()
        return estacionEsqui
    }

    //Menus ----------------------------------------------------------------------------------------
    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        menuInflater.inflate(R.menu.menu, menu)
        return true
    }

    // Manejar las selecciones de menú
    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        return when (item.itemId) {
            R.id.editar -> {
                mostrarDialogoEditar()
                true
            }

            R.id.update -> {
                actualizarLabel()
                initRecyclerView()
                Toast.makeText(this, "Se ha actualizado correctamente", Toast.LENGTH_SHORT).show();
                true
            }

            else -> super.onOptionsItemSelected(item)
        }
    }

    private fun mostrarDialogoEditar() {
        val editText = EditText(this)
        val dialog = AlertDialog.Builder(this)
            .setTitle("Editar")
            .setMessage("Introduce el ID")
            .setView(editText)
            .setPositiveButton("Continuar") { dialog, _ ->
                val idStr = editText.text.toString()
                opcionesEsqui(idStr)
                dialog.dismiss()
            }
            .setNegativeButton("Cancelar") { dialog, _ ->
                dialog.dismiss()
            }
            .create()
        dialog.show()
    }

    fun opcionesEsqui(idUsuario: String){

        if (idUsuario.isNotEmpty()) {
            try {
                val idNumeroUsuario = idUsuario.toInt()//lo pasamos a int

                if (manager.existeIdEstacion(idNumeroUsuario)) {//el id si existe

                    val idBBDD = manager.obtenerEstacionPorId(idNumeroUsuario)

                    val id = idBBDD?.id

                    //val idBBDD = manager.obtenerIdEstacion(idNumeroUsuario)

                    val intent = Intent(this, EditEsqui::class.java)

                    Log.d("ESTACION_123", "ID usuario: $idNumeroUsuario + ID BBDD: $id")

                    intent.putExtra("ID_ESTACION", id)//pasamos el id de la bbdd
                    startActivity(intent)

                } else {//el id que introduce el usuario no existe
                    Toast.makeText(this, "El ID no existe: $idNumeroUsuario", Toast.LENGTH_SHORT).show()
                }
            } catch (e: NumberFormatException) { }
        } else {
            Toast.makeText(this, "Debes ingresar un ID", Toast.LENGTH_SHORT).show()
        }
    }
}
//-----------------------------------------------------------------------------------------------