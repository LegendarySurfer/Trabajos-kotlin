package com.example.estacionesqui

import BDManager
import android.app.DatePickerDialog
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.widget.DatePicker
import android.widget.Toast
import com.example.estacionesqui.BBDD.BDHelper
import com.example.estacionesqui.databinding.ActivityEditEsquiBinding
import com.example.estacionesqui.databinding.ActivityMainBinding
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

class EditEsqui : AppCompatActivity() {

    private lateinit var binding: ActivityEditEsquiBinding
    private lateinit var manager: BDManager
    private lateinit var helper: BDHelper
    private var calendar = Calendar.getInstance()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityEditEsquiBinding.inflate(layoutInflater)
        setContentView(binding.root)

        helper = BDHelper(this)
        manager = BDManager(helper.writableDatabase)


        val idEstacion = intent.getIntExtra("ID_ESTACION", 0)
        binding.btnAceptar.setOnClickListener { btnAceptar(idEstacion) }
        binding.btnFecha.setOnClickListener { mostrarCalendario() }
        completarCampos(idEstacion)
    }


//----------------------------------------------------------------------------------------

    private fun actualizarFecha() {
        val formato = "dd/MM/yyyy"
        val sdf = SimpleDateFormat(formato, Locale.getDefault())
        binding.tvResultadoFecha.text = sdf.format(calendar.time)
    }

    private fun mostrarCalendario() {
        val datePicker = DatePickerDialog(
            this,
            { _: DatePicker, year: Int, month: Int, dayOfMonth: Int ->
                calendar.set(year, month, dayOfMonth)
                actualizarFecha()
            },
            calendar.get(Calendar.YEAR),
            calendar.get(Calendar.MONTH),
            calendar.get(Calendar.DAY_OF_MONTH)
        )

        datePicker.show()
    }

    //----------------------------------------------------------------------------------------

    private fun btnAceptar(id: Int) {
        val nombre = binding.etNombre.text.toString()
        val cordillera = binding.etCordillera.text.toString()
        val nRemontes = binding.etRemontes.text.toString().toIntOrNull() ?: 0
        val kmPistas = binding.etPista.text.toString().toFloatOrNull() ?: 0f
        val valoracion = binding.ratingBar.rating
        val notas = binding.tvNotas.text.toString()
        val fechaUltVisita = obtenerFechaUltimaVisitaEnMillis() // Aquí obtén la fecha en formato Long

        if (manager.existeIdEstacion(id)) { // Se modifica el registro existente
            manager.actualizarEstacion(id, nombre, cordillera, nRemontes, kmPistas, fechaUltVisita, valoracion, notas)
            Toast.makeText(this, "Se ha actualizado correctamente el registro", Toast.LENGTH_SHORT).show()
        } else { // Se inserta un nuevo registro
            if(!(nombre.isEmpty() && cordillera.isEmpty())){
                manager.insertarEstacion(nombre, cordillera, nRemontes, kmPistas, fechaUltVisita, valoracion, notas)

                Toast.makeText(this, "Se ha insertado correctamente el nuevo registro", Toast.LENGTH_SHORT).show()
            }else{
                Toast.makeText(this, "datos erroneos", Toast.LENGTH_SHORT).show()

            }

        }
        finish()
    }

    private fun obtenerFechaUltimaVisitaEnMillis(): Long {
        val calendar = Calendar.getInstance() // Obtiene una instancia del calendario

        // Obtener el año, mes y día actual
        val anio = calendar.get(Calendar.YEAR)
        val mes = calendar.get(Calendar.MONTH)
        val dia = calendar.get(Calendar.DAY_OF_MONTH)

        // Configurar la fecha en el calendario
        calendar.set(anio, mes, dia)

        // Devolver la fecha en milisegundos
        return calendar.timeInMillis
    }


    private fun completarCampos(id: Int) {
        val estacion = manager.obtenerEstacionPorId(id)

        // Verificar si se encontró la estación
        if (estacion != null) {
            // Rellenar los campos con los valores de la estación
            binding.etNombre.setText(estacion.nombre)
            binding.etCordillera.setText(estacion.cordillera)
            binding.etRemontes.setText(estacion.nRemontes.toString())
            binding.etPista.setText(estacion.kmPistas.toString())
            binding.tvNotas.setText(estacion.notas.toString())
            binding.ratingBar.rating = estacion.valoracion
            val fechaFormato = SimpleDateFormat("dd/MM/yyyy", Locale.getDefault())
            val fechaTexto = fechaFormato.format(Date(estacion.fechaUltVisita))
            binding.tvResultadoFecha.text = fechaTexto
        }
    }
}