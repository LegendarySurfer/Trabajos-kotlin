package com.example.estacionesqui.Adapter

import android.annotation.SuppressLint
import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.estacionesqui.Clases.EstacionEsqui
import com.example.estacionesqui.R

class Adapter(private val context: Context, private val estacionesList: List<EstacionEsqui>) :
    RecyclerView.Adapter<Adapter.EstacionEsquiViewHolder>() {

    private var longClickListener: OnItemLongClickListener? = null//variable del clic

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): EstacionEsquiViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item, parent, false)
        return EstacionEsquiViewHolder(view)
    }

    override fun onBindViewHolder(holder: EstacionEsquiViewHolder, position: Int) {
        val estacion = estacionesList[position]
        holder.bind(estacion)

        //escucha del clic largo
        holder.itemView.setOnLongClickListener {
            longClickListener?.onItemLongClick(it, position)
            true
        }
    }
    fun setOnItemLongClickListener(listener: OnItemLongClickListener) {
        longClickListener = listener
    }

    override fun getItemCount(): Int {
        return estacionesList.size
    }

    inner class EstacionEsquiViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        private val nombreTextView: TextView = itemView.findViewById(R.id.textView1)
        private val cordilleraTextView: TextView = itemView.findViewById(R.id.textView2)

        @SuppressLint("SetTextI18n")
        fun bind(estacion: EstacionEsqui) {
            nombreTextView.text = estacion.nombre
            cordilleraTextView.text = "Cordillera: ${estacion.cordillera}" +
                    "Nº Remontes: ${estacion.nRemontes}" + "Km de pistas: ${estacion.kmPistas}" +
                    "Fecha última visita: ${estacion.fechaUltVisita}" + "Valoración: ${estacion.valoracion}" +
                    "Notas: ${estacion.notas}"

        }
    }
    //interfaz para el clic largo
    interface OnItemLongClickListener {
        fun onItemLongClick(view: View?, position: Int)
    }
    //---------------------------------------------------------------------------------------------
}