import android.annotation.SuppressLint
import android.content.ContentValues
import android.database.Cursor
import android.database.sqlite.SQLiteDatabase
import com.example.estacionesqui.BBDD.BDContract
import com.example.estacionesqui.Clases.EstacionEsqui

class BDManager(private val db: SQLiteDatabase) {

    fun obtenerNumeroRegistros(): Int {
        val query = "SELECT COUNT(*) FROM ${BDContract.Esqui.tableName};"
        val cursor: Cursor = db.rawQuery(query, null)
        var count = 0
        if (cursor.moveToFirst()) {
            count = cursor.getInt(0)
        }
        cursor.close()
        return count
    }

    fun obtenerIdEstacion(posicion: Int): Int {
        val query = "SELECT ${BDContract.Esqui.COLUMN_ID} FROM ${BDContract.Esqui.tableName};"
        val cursor: Cursor = db.rawQuery(query, null)
        var id = -1 // Valor predeterminado en caso de que no se encuentre el ID
        if (cursor.moveToFirst()) {
            cursor.move(posicion)
            id = cursor.getInt(0)
        }
        cursor.close()
        return id - 1
    }

    fun borrarEstacion(id: Int): Int {
        return db.delete(BDContract.Esqui.tableName, "${BDContract.Esqui.COLUMN_ID} = ?", arrayOf(id.toString()))
    }

    fun existeIdEstacion(id: Int): Boolean {
        val query = "SELECT COUNT(*) FROM ${BDContract.Esqui.tableName} WHERE ${BDContract.Esqui.COLUMN_ID} = ?"
        val cursor: Cursor = db.rawQuery(query, arrayOf(id.toString()))
        cursor.moveToFirst()
        val count = cursor.getInt(0)
        cursor.close()
        return count > 0
    }

    @SuppressLint("Range")
    fun obtenerEstacionPorId(id: Int): EstacionEsqui? {
        val query = "SELECT * FROM ${BDContract.Esqui.tableName} WHERE ${BDContract.Esqui.COLUMN_ID} = ?"
        val cursor = db.rawQuery(query, arrayOf(id.toString()))

        var estacion: EstacionEsqui? = null

        if (cursor.moveToFirst()) {
            val nombre = cursor.getString(cursor.getColumnIndex(BDContract.Esqui.COLUMN_NOMBRE))
            val cordillera = cursor.getString(cursor.getColumnIndex(BDContract.Esqui.COLUMN_CORDILLERA))
            val nRemontes = cursor.getInt(cursor.getColumnIndex(BDContract.Esqui.COLUMN_N_REMONTES))
            val kmPistas = cursor.getFloat(cursor.getColumnIndex(BDContract.Esqui.COLUMN_KM_PISTAS))
            val fechaUltVisita = cursor.getLong(cursor.getColumnIndex(BDContract.Esqui.COLUMN_FECHA_ULT_VISITA))
            val valoracion = cursor.getFloat(cursor.getColumnIndex(BDContract.Esqui.COLUMN_VALORACION))
            val notas = cursor.getString(cursor.getColumnIndex(BDContract.Esqui.COLUMN_NOTAS))

            estacion = EstacionEsqui(id, nombre, cordillera, nRemontes, kmPistas, fechaUltVisita, valoracion, notas)
        }

        cursor.close()
        return estacion
    }

    fun insertarEstacion( nombre: String, cordillera: String, nRemontes: Int, kmPistas: Float, fechaUltVisita: Long, valoracion: Float, notas: String) {
        val contentValues = ContentValues().apply {
            put(BDContract.Esqui.COLUMN_NOMBRE, nombre)
            put(BDContract.Esqui.COLUMN_CORDILLERA, cordillera)
            put(BDContract.Esqui.COLUMN_N_REMONTES, nRemontes)
            put(BDContract.Esqui.COLUMN_KM_PISTAS, kmPistas)
            put(BDContract.Esqui.COLUMN_FECHA_ULT_VISITA, fechaUltVisita)
            put(BDContract.Esqui.COLUMN_VALORACION, valoracion)
            put(BDContract.Esqui.COLUMN_NOTAS, notas)
        }
        db.insert(BDContract.Esqui.tableName, null, contentValues)
    }

    fun actualizarEstacion(id: Int, nombre: String, cordillera: String, nRemontes: Int, kmPistas: Float, fechaUltVisita: Long, valoracion: Float, notas: String) {
        val contentValues = ContentValues().apply {
            put(BDContract.Esqui.COLUMN_NOMBRE, nombre)
            put(BDContract.Esqui.COLUMN_CORDILLERA, cordillera)
            put(BDContract.Esqui.COLUMN_N_REMONTES, nRemontes)
            put(BDContract.Esqui.COLUMN_KM_PISTAS, kmPistas)
            put(BDContract.Esqui.COLUMN_FECHA_ULT_VISITA, fechaUltVisita)
            put(BDContract.Esqui.COLUMN_VALORACION, valoracion)
            put(BDContract.Esqui.COLUMN_NOTAS, notas)
        }
        val selection = "${BDContract.Esqui.COLUMN_ID} = ?"
        val selectionArgs = arrayOf(id.toString())
        db.update(BDContract.Esqui.tableName, contentValues, selection, selectionArgs)
    }

}
