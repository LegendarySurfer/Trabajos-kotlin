package com.example.estacionesqui.BBDD

import android.provider.BaseColumns

object BDContract {

    object Esqui: BaseColumns {
        const val tableName = "Esqui"
        const val item_nameRes = "item_nameRes"
        const val item_iconRes = "item_iconRes"

        const val COLUMN_ID = "_id"
        const val COLUMN_NOMBRE = "nombre"
        const val COLUMN_CORDILLERA = "cordillera"
        const val COLUMN_N_REMONTES = "n_remontes"
        const val COLUMN_KM_PISTAS = "km_pistas"
        const val COLUMN_FECHA_ULT_VISITA = "fecha_ult_visita"
        const val COLUMN_VALORACION = "valoracion"
        const val COLUMN_NOTAS = "notas"

    }

    fun crearTabla(): String {
        return "CREATE TABLE ${Esqui.tableName} (" +
                "${Esqui.COLUMN_ID} integer primary key autoincrement, " +
                "${Esqui.COLUMN_NOMBRE} text not null, " +
                "${Esqui.COLUMN_CORDILLERA} text not null, " +
                "${Esqui.COLUMN_N_REMONTES} int not null, " +
                "${Esqui.COLUMN_KM_PISTAS} float, " +
                "${Esqui.COLUMN_FECHA_ULT_VISITA} long, " +
                "${Esqui.COLUMN_VALORACION} float, " +
                "${Esqui.COLUMN_NOTAS} text);"
    }

    val inserts = arrayListOf(
        "INSERT INTO ${Esqui.tableName} VALUES(1,'Alto Campoo','Cantábrica',13,27,1,4,'Para un fin de semana');",
        "INSERT INTO ${Esqui.tableName} VALUES(2,'Formigal','Pirineo Aragonés',21,130,45990000000,10,'Para una buena semana');",
        "INSERT INTO ${Esqui.tableName} VALUES(3,'Baqueira','Pirineo Catalán',37,140,45990000000,1,'Muy cara');",
        "INSERT INTO ${Esqui.tableName} VALUES(4,'Navacerrada','Sistema Central',10,70,45990000000,7,'Mucha gente');"
    )


}