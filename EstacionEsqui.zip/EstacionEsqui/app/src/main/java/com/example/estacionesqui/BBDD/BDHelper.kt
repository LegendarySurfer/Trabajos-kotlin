package com.example.estacionesqui.BBDD

import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

class BDHelper(
    contexto: Context?,
) : SQLiteOpenHelper(contexto, name, null, version) {

    companion object{
        const val name = "BDEsqui.db"
        const val version = 10
    }

    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL(BDContract.crearTabla())
        BDContract.inserts.forEach{
            db.execSQL(it)
        }
    }

    //esto lo hace cuando se actualiza la version
    override fun onUpgrade(db: SQLiteDatabase, versionAnterior: Int, versionNueva: Int) {
        db.execSQL("DROP TABLE IF EXISTS ${BDContract.Esqui.tableName}")
        onCreate(db)
    }

}
