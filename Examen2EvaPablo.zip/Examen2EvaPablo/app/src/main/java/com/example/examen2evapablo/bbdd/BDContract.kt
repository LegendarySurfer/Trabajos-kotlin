package com.example.examen2evapablo.bbdd

import android.provider.BaseColumns

object BDContract {

    //columnas de la tabla y nombre de la tabla
    object Diputado: BaseColumns {
        const val tableName = "Diputado"

        const val COLUMN_SERVICIOS = "n_servicios"
        const val COLUMN_NOMBRE = "nombre"
        const val COLUMN_FECHA = "fecha"

    }

    //creacion de la tabla
    fun crearTabla():String{
        return "CREATE TABLE ${Diputado.tableName} (" +
                "${Diputado.COLUMN_SERVICIOS}, " +
                "${Diputado.COLUMN_NOMBRE}, " +
                "${Diputado.COLUMN_FECHA});"
    }


    //datos por defecto
    val inserts = arrayListOf(
        "INSERT INTO ${Diputado.tableName} VALUES(1,'Alto Campoo','12/10/2022');"
    )

}