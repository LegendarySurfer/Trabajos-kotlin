package com.example.examen2evapablo.bbdd

import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

class BDHelper(
    contexto: Context?,
) : SQLiteOpenHelper(contexto, name, null, version) {

    companion object{
        const val name = "BDiputados.db" // nombre de la bbdd
        const val version = 1 // el numero de la version
    }

    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL(BDContract.crearTabla())//creamos la tabla
        BDContract.inserts.forEach{ //agregamos datos a la bbdd
            db.execSQL(it)
        }
    }

    //esto lo hace cuando se actualiza la version
    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        db.execSQL("DROP TABLE IF EXISTS ${BDContract.Diputado.tableName}")
        onCreate(db)
    }

}