package com.example.examen2evapablo.bbdd

import android.annotation.SuppressLint
import android.content.ContentValues
import android.database.sqlite.SQLiteDatabase
import com.example.examen2evapablo.adapter.Diputado


class BDManager(private val db: SQLiteDatabase) {

    fun insertarDiputado(n_servicio: String, nombre: String, fecha: String) {
        val contentValues = ContentValues().apply {
            put(BDContract.Diputado.COLUMN_SERVICIOS, n_servicio)
            put(BDContract.Diputado.COLUMN_NOMBRE, nombre)
            put(BDContract.Diputado.COLUMN_FECHA, fecha)

        }
        db.insert(BDContract.Diputado.tableName, null, contentValues)
    }

    fun borrarDiputado(nombre: String): Int {
        return db.delete(BDContract.Diputado.tableName, "${BDContract.Diputado.COLUMN_NOMBRE} = ?", arrayOf(nombre))
    }

    @SuppressLint("Range")
    fun obtenerNombreDiputadoPorPosicion(posicion: Int): String? {
        val query = "SELECT ${BDContract.Diputado.COLUMN_NOMBRE} FROM ${BDContract.Diputado.tableName} LIMIT 1 OFFSET $posicion"
        val cursor = db.rawQuery(query, null)
        var nombre: String? = null
        cursor.use {
            if (it.moveToFirst()) {
                nombre = it.getString(it.getColumnIndex(BDContract.Diputado.COLUMN_NOMBRE))
            }
        }
        return nombre
    }

    @SuppressLint("Range")
    fun obtenerDatoDiputado(nombre: String): Diputado? {
        val query = "SELECT * FROM ${BDContract.Diputado.tableName} WHERE ${BDContract.Diputado.COLUMN_NOMBRE} = ?"
        val cursor = db.rawQuery(query, arrayOf(nombre))

        var diputado: Diputado? = null

        if (cursor.moveToFirst()) {
            val numeroServicio = cursor.getString(cursor.getColumnIndex(BDContract.Diputado.COLUMN_SERVICIOS))
            val fecha = cursor.getString(cursor.getColumnIndex(BDContract.Diputado.COLUMN_FECHA))
            diputado = Diputado(numeroServicio, nombre, fecha)
        }

        cursor.close()
        return diputado
    }


    fun actualizarDiputado(nombre: String, servicio: String, fecha: String) {
        val contentValues = ContentValues().apply {
            put(BDContract.Diputado.COLUMN_SERVICIOS, servicio)
            put(BDContract.Diputado.COLUMN_NOMBRE,nombre)
            put(BDContract.Diputado.COLUMN_FECHA,fecha)

        }
        val selection = "${BDContract.Diputado.COLUMN_NOMBRE} = ?"
        val selectionArgs = arrayOf(nombre.toString())
        db.update(BDContract.Diputado.tableName, contentValues, selection, selectionArgs)
    }

}