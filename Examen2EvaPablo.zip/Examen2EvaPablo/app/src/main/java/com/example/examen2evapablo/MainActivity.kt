package com.example.examen2evapablo

import android.annotation.SuppressLint
import android.app.DatePickerDialog
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.DatePicker
import android.widget.PopupMenu
import android.widget.Toast
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.examen2evapablo.adapter.Diputado
import com.example.examen2evapablo.bbdd.BDContract
import com.example.examen2evapablo.bbdd.BDHelper
import com.example.examen2evapablo.bbdd.BDManager
import com.example.examen2evapablo.databinding.ActivityMainBinding
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale
import com.example.examen2evapablo.adapter.Adapter


class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private lateinit var recyclerView: RecyclerView
    private var calendar = Calendar.getInstance()
    private lateinit var adapter: com.example.examen2evapablo.adapter.Adapter
    private lateinit var helper: BDHelper
    private lateinit var manager: BDManager
    private var contador: Int = 0


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        helper = BDHelper(this)
        manager = BDManager(helper.writableDatabase)

        initRecyclerView()
       initUI()
    }
    override fun onResume() {
        super.onResume()
        initRecyclerView()
    }

    private fun initUI(){
        binding.tvFehca.setOnClickListener { mostrarCalendario() } //mostrar calendario
        binding.btnAgregar.setOnClickListener { agregarDiputado() }
        binding.btnResta.setOnClickListener {
            if (contador > 0) {
                contador--
                binding.tvContador.text = contador.toString()
            } else {
                Toast.makeText(this, "El número no puede ser negativo", Toast.LENGTH_SHORT).show()
            }
        }

        binding.btnSuma.setOnClickListener {
            contador++
            binding.tvContador.text = contador.toString()
        }
    }

    private fun agregarDiputado() {
        if (!binding.tvContador.text.toString().equals("0")) {
            manager.insertarDiputado(
                binding.tvContador.text.toString(),
                binding.inptName.text.toString(),
                binding.tvFehca.text.toString()
            )
            initRecyclerView()//actualizar lista
        } else {
            Toast.makeText(this, "El número no puede ser 0", Toast.LENGTH_SHORT).show()
        }
    }


    //----------------------------------------------------------------------------------------------
    private fun initRecyclerView() {
        recyclerView = binding.rvDiputados
        recyclerView.layoutManager = LinearLayoutManager(this)
        adapter = Adapter(obtenerDiputadosDesdeBD())
        recyclerView.adapter = adapter

        adapter.setOnItemLongClickListener(object : Adapter.OnItemLongClickListener {
            override fun onItemLongClick(view: View?, position: Int) {
                //mostrar mensaje
                mostrarMenuContextual(position)
            }
        })
    }

    @SuppressLint("Range")
    private fun obtenerDiputadosDesdeBD(): ArrayList<Diputado> {
        val cursor =
            helper.readableDatabase.rawQuery("SELECT * FROM ${BDContract.Diputado.tableName}", null)
        val estacionEsqui = arrayListOf<Diputado>()

        if (cursor.moveToFirst()) {
            do {
                val n_servicios =
                    cursor.getString(cursor.getColumnIndex(BDContract.Diputado.COLUMN_SERVICIOS))
                val nombre = cursor.getString(cursor.getColumnIndex(BDContract.Diputado.COLUMN_NOMBRE))
                val fecha = cursor.getString(cursor.getColumnIndex(BDContract.Diputado.COLUMN_FECHA))


                val diputados = Diputado(
                    n_servicios,
                    nombre,
                    fecha

                )
                estacionEsqui.add(diputados)
            } while (cursor.moveToNext())
        }
        cursor.close()
        return estacionEsqui
    }


    //----------------------------------------------------------------------------------------------
    private fun mostrarCalendario() {
        val datePicker = DatePickerDialog(
            this,
            { _: DatePicker, year: Int, month: Int, dayOfMonth: Int ->
                calendar.set(year, month, dayOfMonth)
                actualizarFecha()
            },
            calendar.get(Calendar.YEAR),
            calendar.get(Calendar.MONTH),
            calendar.get(Calendar.DAY_OF_MONTH)
        )

        datePicker.show()
    }

    private fun actualizarFecha() {
        val formato = "dd/MM/yyyy"
        val sdf = SimpleDateFormat(formato, Locale.getDefault())
        binding.tvFehca.text = sdf.format(calendar.time)
    }

    //----------------------------------------------------------------------------------------------

    private fun mostrarMenuContextual(position: Int) {
        val popupMenu = PopupMenu(this, recyclerView.getChildAt(position))
        popupMenu.inflate(R.menu.context_menu)
        popupMenu.setOnMenuItemClickListener { menuItem ->
            val nombre =  manager.obtenerNombreDiputadoPorPosicion(position)
            when (menuItem.itemId) {
                R.id.option1 -> {//borrado

                    if (nombre != null) {
                        manager.borrarDiputado(nombre)//se borra de la bbdd
                        initRecyclerView()
                    }
                    true
                }


                R.id.option2 -> {//actualizar
                    val intent = Intent(this, ActualizarDiputado::class.java).apply {
                        putExtra("NOMBRE",nombre)

                    }
                    startActivity(intent)
                    initRecyclerView()
                    true
                }
                else -> false
            }
        }
        popupMenu.show()
    }

}