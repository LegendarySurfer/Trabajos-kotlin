package com.example.examen2evapablo.adapter

data class Diputado(
    val n_ervicios: String,
    val nombre:String,
    val fecha:String
)