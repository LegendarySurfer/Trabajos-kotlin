package com.example.examen2evapablo

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Toast
import com.example.examen2evapablo.bbdd.BDHelper
import com.example.examen2evapablo.bbdd.BDManager
import com.example.examen2evapablo.databinding.ActivityActualizarDiputadoBinding

class ActualizarDiputado : AppCompatActivity() {

    private lateinit var binding: ActivityActualizarDiputadoBinding
    private lateinit var helper: BDHelper
    private lateinit var manager: BDManager


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityActualizarDiputadoBinding.inflate(layoutInflater)
        setContentView(binding.root)



        val nombre = intent.getStringExtra("NOMBRE")

        helper = BDHelper(this)
        manager = BDManager(helper.writableDatabase)


        initUI(nombre.toString())
    }

    private fun initUI(nombre: String) {
        val diputado = manager.obtenerDatoDiputado(nombre)
        if (diputado != null) {
            binding.tvNombre.text = diputado.nombre
            binding.editTextText.setText(diputado.n_ervicios)
            binding.editTextText2.setText(diputado.fecha)
        }

        binding.btnVolver.setOnClickListener {
            manager.actualizarDiputado(binding.tvNombre.text.toString(),
                binding.editTextText.text.toString(),
                binding.editTextText2.text.toString())
            finish() }
    }
}