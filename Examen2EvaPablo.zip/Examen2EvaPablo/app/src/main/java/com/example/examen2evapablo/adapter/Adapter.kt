package com.example.examen2evapablo.adapter


import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.examen2evapablo.R

class Adapter(private val diputadosList: List<Diputado>) :
    RecyclerView.Adapter<Adapter.DiputadoViewHolder>() {

    private var longClickListener: OnItemLongClickListener? = null//variable del clic

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): DiputadoViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_layout, parent, false)
        return DiputadoViewHolder(view)
    }

    override fun onBindViewHolder(holder: DiputadoViewHolder, position: Int) {
        holder.bind(diputadosList[position])

        holder.itemView.setOnLongClickListener {
            longClickListener?.onItemLongClick(it, position)
            true
        }
    }


    fun setOnItemLongClickListener(listener: OnItemLongClickListener) {
        longClickListener = listener
    }

    override fun getItemCount(): Int = diputadosList.size

    inner class DiputadoViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        private val serviciosTextView: TextView = itemView.findViewById(R.id.i_nServicios)
        private val nombreTextView: TextView = itemView.findViewById(R.id.i_nombre)
        private val fechaTextView: TextView = itemView.findViewById(R.id.i_fecha)

        fun bind(diputado: Diputado) {
            serviciosTextView.text = diputado.n_ervicios.toString()
            nombreTextView.text = diputado.nombre
            fechaTextView.text = diputado.fecha

        }
    }

    //interfaz para el clic largo
    interface OnItemLongClickListener {
        fun onItemLongClick(view: View?, position: Int)
    }

}